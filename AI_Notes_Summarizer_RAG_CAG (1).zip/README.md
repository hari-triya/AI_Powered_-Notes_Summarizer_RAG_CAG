# AI Powered Notes Summarizer and Question Answering System (RAG + CAG)

Seventh Semester Final Year Capstone Project – Google Colab implementation.

## What it does
Upload PDF/TXT notes, get AI summaries, and ask questions answered **only from your notes**.
- **RAG**: Sentence Transformers embeddings + FAISS similarity search -> relevant chunks -> Navigate Labs **Nexus API**.
- **CAG**: repeated questions are answered from a cache (no API call). The cache is tied to a document fingerprint, so changed documents never return old answers.
- **Gradio** interface runs inside Colab.
- **Nexus API is the only LLM provider.** No other LLM service is used, and there is no silent fallback.

## How to run in Google Colab
1. Open https://colab.research.google.com -> **File -> Upload notebook** -> choose `AI_Notes_Summarizer_RAG_CAG.ipynb`.
2. Click the key icon (Secrets) on the left, add a secret named `NEXUS_API_KEY` with your college key, and switch **Notebook access** ON. (If you skip this, Cell 4 asks for the key in a hidden box.)
3. Run the cells from top to bottom (`Runtime -> Run all` also works). In Cell 5 choose a model from the list your key can use.
4. Cell 16 shows the interface. Cell 17 runs the 20 tests. Cell 18 shows the final statistics and the CAG demo.
5. After capturing your 8 screenshots (see `SCREENSHOT_GUIDE.md`), run Cell 19 to build the ZIP.

## Files in this package
| File / folder | Purpose |
|---|---|
| `AI_Notes_Summarizer_RAG_CAG.ipynb` | The complete notebook (19 cells) |
| `README.md` | This file |
| `SCREENSHOT_GUIDE.md` | How to take the 8 genuine screenshots |
| `requirements.txt` | Libraries used (installed by Cell 2) |
| `diagrams/` | 5 architecture / workflow diagrams (PNG) |
| `implementation_screenshots/` | Put your 8 real screenshots here |
| `test_results.json` | Written by Cell 17 when you run it (not included until you run the tests) |

## Important notes
- **API limits are never invented.** Public Nexus documentation (rate limits, token limits, model list) was not available when this project was built. The notebook reads the model list from the API, records any rate-limit headers the API sends, handles 429/timeout/auth/server errors with limited retries and exponential backoff (respecting `Retry-After`), and lets you enter RPM/TPM limits **only if your college provides them** (Cell 3).
- `MAX_CONTEXT_CHARS` and `SUMMARY_BATCH_CHARS` are the project's own safety budgets, not Nexus limits.
- Scanned (image-only) PDFs are rejected because this project does not include OCR.
- Test results are only valid when you run Cell 17 yourself with your API key. Tests that cannot run are shown as SKIPPED, never as passed.
- The API key is never stored in the notebook or printed.
