# Screenshot Capture Guide (8 genuine screenshots)

All screenshots must be taken from **your own running notebook**. Do not edit, mock up or download images.
Save them in `implementation_screenshots/` using the file names below.
**Before every screenshot:** make sure the API key is not visible (Cell 4 uses a hidden box and never prints it; do not screenshot Colab Secrets).

Suggested test files: one PDF and one TXT of your own notes (or the sample files from `CREATE_SAMPLE_FILES = True` in Cell 6).

| Figure | File name | What to show | How to get it |
|---|---|---|---|
| 10.1 | `Figure_10_1_Application_Home_Page.png` | Home page / project interface | Run Cell 16. Capture the title area and the tabs before uploading anything. |
| 10.2 | `Figure_10_2_Document_Upload.png` | Upload showing PDF and TXT files | Tab "1 Upload & Process": select one PDF and one TXT so both names show in the upload box. |
| 10.3 | `Figure_10_3_Processing_and_Extraction.png` | Processing status + extracted text | Press **Process Documents**. Capture the status, the document table and the extracted text preview. |
| 10.4 | `Figure_10_4_Summaries.png` | Short and Detailed summaries | Tab "2 Summaries": generate *Short Summary*, then *Detailed Summary* (scroll so both are visible, or take one screenshot per type and place them side by side in your report). |
| 10.5 | `Figure_10_5_RAG_Answer.png` | Question, answer, retrieved context | Tab "3 Ask Questions": ask a question about your notes. Capture the answer, sources and retrieved context. |
| 10.6 | `Figure_10_6_CAG_Miss_and_Hit.png` | Cache MISS then Cache HIT | Ask a NEW question (shows MISS) and capture; ask the same question again (shows HIT, 0 API calls) and capture both, or use Cell 18's live demo output. |
| 10.7 | `Figure_10_7_Sources_and_API_Status.png` | Source file + page, API usage/status | Capture the source list under an answer plus the "4 API Status" tab (calls, tokens, retries, rate-limit headers). |
| 10.8 | `Figure_10_8_Final_Output.png` | Final answer and project results | Capture a completed answer together with the cache statistics, or the Cell 18 final results and chart. |

Tips: use the browser zoom (Ctrl +/-) so text is readable; Windows `Win+Shift+S`, macOS `Cmd+Shift+4`.

**Adding them to the ZIP:** put the PNG files into the Colab folder `implementation_screenshots/` (left file panel) or set `UPLOAD_SCREENSHOTS_NOW = True` in Cell 19 and select them. Cell 19 lists which of the 8 are missing.
